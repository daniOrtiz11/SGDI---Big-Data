# coding=utf-8
"""Sistemas de Gestión de Datos y de la Información
   Práctica 1 (MapReduce & Apache Spark)
   Grupo 04 - Sergio González Francisco / Daniel Ortiz Sánchez
   Sergio González Francisco y Daniel Ortiz Sánchez declaramos que esta solución es fruto
   exclusivamente de nuestro trabajo personal. No hemos sido ayudados por ninguna otra
   persona ni hemos obtenido la solución de fuentes externas, y tampoco hemos compartido
   nuestra solución con nadie. Declaramos además que no hemos realizado de manera
   deshonesta ninguna otra actividad que pueda mejorar nuestros resultados ni perjudicar los
   resultados de los demás."""

import sys
from pyspark.sql import SparkSession


def main():

  # Cargamos los ficheros csv directamente como dataframes      
  spark = SparkSession.builder.getOrCreate()
  sc = spark.sparkContext
  df1 = spark.read.format("csv").option("header", "true").load("simpsons_characters.csv")
  df2 = spark.read.format("csv").option("header", "true").load("simpsons_episodes.csv")
  df3 = spark.read.format("csv").option("header", "true").load("simpsons_locations.csv")
  df4 = spark.read.format("csv").option("header", "true").load("simpsons_script_lines.csv")
  #Mostramos los dataframes cargados anteriormente
  df1.show()
  df2.show()
  df3.show()
  df4.show()

  sc.stop()

# Punto de entrada del programa al cargarlo con spark-submit
if __name__ == "__main__":
  main()
