# coding=utf-8
"""Sistemas de Gestión de Datos y de la Información
   Práctica 1 (MapReduce & Apache Spark)
   Grupo 04 - Sergio González Francisco / Daniel Ortiz Sánchez
   Sergio González Francisco y Daniel Ortiz Sánchez declaramos que esta solución es fruto
   exclusivamente de nuestro trabajo personal. No hemos sido ayudados por ninguna otra
   persona ni hemos obtenido la solución de fuentes externas, y tampoco hemos compartido
   nuestra solución con nadie. Declaramos además que no hemos realizado de manera
   deshonesta ninguna otra actividad que pueda mejorar nuestros resultados ni perjudicar los
   resultados de los demás."""

import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions



def main():

  # Cargamos los ficheros csv directamente como dataframes      
  spark = SparkSession.builder.getOrCreate()
  sc = spark.sparkContext
  df1 = spark.read.format("csv").option("header", "true").load("simpsons_characters.csv")
  df2 = spark.read.format("csv").option("header", "true").load("simpsons_episodes.csv")
  df3 = spark.read.format("csv").option("header", "true").load("simpsons_locations.csv")
  df4 = spark.read.format("csv").option("header", "true").load("simpsons_script_lines.csv")

  dfScriptLines = df4.groupBy('episode_id').agg(functions.approx_count_distinct(df4.location_id).alias("count")).selectExpr("episode_id as id", "count")

  dfLocations = df2.join(dfScriptLines, on = "id", how = 'outer').select("id","imdb_rating","count")

  dfLocations.show()

  sc.stop()

# Punto de entrada del programa al cargarlo con spark-submit
if __name__ == "__main__":
  main()
