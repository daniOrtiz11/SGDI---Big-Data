# coding=utf-8
"""Sistemas de Gestión de Datos y de la Información
   Práctica 1 (MapReduce & Apache Spark)
   Grupo 04 - Sergio González Francisco / Daniel Ortiz Sánchez
   Sergio González Francisco y Daniel Ortiz Sánchez declaramos que esta solución es fruto
   exclusivamente de nuestro trabajo personal. No hemos sido ayudados por ninguna otra
   persona ni hemos obtenido la solución de fuentes externas, y tampoco hemos compartido
   nuestra solución con nadie. Declaramos además que no hemos realizado de manera
   deshonesta ninguna otra actividad que pueda mejorar nuestros resultados ni perjudicar los
   resultados de los demás."""

from mrjob.job import MRJob
import os
import string

class MRDatosMeteo(MRJob):

  # Fase MAP (line es una cadena de texto)
  def mapper(self, key, line):
     line = line.lower() 
     file_name = os.environ['map_input_file']
     for palabra in line.split():
        for a in string.punctuation:
           palabra = palabra.replace(a, '')
        if(palabra != " " or palabra != ""):
           dic = {}
           dic[file_name] = 1
           yield palabra, dic
  
  #Fase Combiner (key es una cadena de texto, values un generador de valores)
  def combiner(self, key, values):
     dic = {}
     #Agrupacion de valores
     for d in values:
        for e,v in d.items():
           if e in dic:
              dic[e] = dic[e] + v
           else:
              dic[e] = v
     yield key, dic

  # Fase REDUCE (key es una cadena texto, values un generador de valores)
  def reducer(self, key, values):
     #contadores que identifican cuantas veces ha llegado cada libro en values 
     contadventures = 0
     conthamlet = 0
     contmoby = 0
     for d in values:
        for e,v in d.items():
           if(e == 'Adventures_of_Huckleberry_Finn.txt'):
              contadventures = contadventures + v
           if(e == 'Hamlet.txt'):
              conthamlet = conthamlet + v
           if(e == 'Moby_Dick.txt'):
              contmoby = contmoby + v
     if(conthamlet > 20 or contadventures > 20 or contmoby > 20):
       dic = {}
       if(contmoby != 0):
          dic["Moby_Dick.txt"] = contmoby    
       if(contadventures != 0):
          dic['Adventures_of_Huckleberry_Finn.txt'] = contadventures   
       if(conthamlet != 0):
          dic['Hamlet.txt'] = conthamlet   
       #pasamos diccionario a lista para ordenar por valor
       l = []
       for k, v in dic.items():
          temp = [k,v]
          l.append(temp)
       l.sort(reverse = True, key=lambda e: e[1])
       yield key, l

if __name__ == '__main__':
    MRDatosMeteo.run()
